﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Veterinaria
{
    public partial class FormPropietarios : Form
    {
        // Rutas de archivos CSV
        private string rutaArchivo = "propietarios.csv";
        private string rutaMascotas = "mascotas.csv";

        public FormPropietarios()
        {
            InitializeComponent();
        }

        // Se ejecuta al abrir el formulario
        private void FormPropietarios_Load(object sender, EventArgs e)
        {
            LimpiarInterfaz();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            // Normalizamos el ID antes de validar (quitar espacios y poner en Mayúscula)
            txtID.Text = txtID.Text.Trim().ToUpper();

            if (ValidarCampos())
            {
                string nuevaLinea = $"{txtID.Text},{txtNombre.Text},{txtTelefono.Text},{txtCorreo.Text},{txtDireccion.Text}";

                if (!File.Exists(rutaArchivo))
                {
                    File.WriteAllText(rutaArchivo, "ID,Nombre,Telefono,Correo,Direccion\n");
                }

                var lineasExistentes = File.ReadAllLines(rutaArchivo);
                if (lineasExistentes.Skip(1).Any(l => l.Split(',')[0] == txtID.Text))
                {
                    MessageBox.Show("El ID ya existe en el sistema.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                File.AppendAllLines(rutaArchivo, new[] { nuevaLinea });
                MessageBox.Show("Propietario registrado con éxito", "VET SALUD");
                LimpiarInterfaz();
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            txtID.Text = txtID.Text.Trim().ToUpper();
            if (string.IsNullOrWhiteSpace(txtID.Text)) return;

            var confirmacion = MessageBox.Show("¿Desea guardar los cambios en este registro?", "Actualizar", MessageBoxButtons.YesNo);
            if (confirmacion == DialogResult.Yes)
            {
                if (File.Exists(rutaArchivo))
                {
                    var lineas = File.ReadAllLines(rutaArchivo).ToList();
                    bool modificado = false;

                    for (int i = 0; i < lineas.Count; i++)
                    {
                        if (lineas[i].StartsWith(txtID.Text + ","))
                        {
                            lineas[i] = $"{txtID.Text},{txtNombre.Text},{txtTelefono.Text},{txtCorreo.Text},{txtDireccion.Text}";
                            modificado = true;
                            break;
                        }
                    }

                    if (modificado)
                    {
                        File.WriteAllLines(rutaArchivo, lineas);
                        MessageBox.Show("Datos actualizados correctamente.");
                        LimpiarInterfaz();
                    }
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvPropietarios.SelectedRows.Count > 0)
            {
                var confirmacion = MessageBox.Show("¿Está seguro de eliminar este propietario?", "Confirmar", MessageBoxButtons.YesNo);
                if (confirmacion == DialogResult.Yes)
                {
                    string idEliminar = dgvPropietarios.SelectedRows[0].Cells[0].Value.ToString();
                    var lineas = File.ReadAllLines(rutaArchivo).Where(l => !l.StartsWith(idEliminar + ",")).ToList();
                    File.WriteAllLines(rutaArchivo, lineas);

                    MessageBox.Show("Propietario eliminado.");
                    LimpiarInterfaz();
                }
            }
            else
            {
                MessageBox.Show("Seleccione una fila en la tabla primero.");
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string filtro = txtBuscar.Text.Trim().ToUpper();

            // 1. Quitamos la gestión de moneda para evitar errores de visibilidad
            dgvPropietarios.CurrentCell = null;

            foreach (DataGridViewRow fila in dgvPropietarios.Rows)
            {
                if (fila.IsNewRow) continue;

                // 2. Obtenemos el valor del Nombre (Columna índice 1) y el ID (Columna índice 0)
                string id = fila.Cells[0].Value?.ToString().ToUpper() ?? "";
                string nombre = fila.Cells[1].Value?.ToString().ToUpper() ?? "";

                // 3. Si el filtro está vacío, mostramos todo. Si no, buscamos coincidencias.
                if (string.IsNullOrEmpty(filtro))
                {
                    fila.Visible = true;
                }
                else
                {
                    // Filtra si el ID o el Nombre contienen lo que escribiste
                    fila.Visible = (id.Contains(filtro) || nombre.Contains(filtro));
                }
            }

            // Actualizamos el contador con las filas que quedaron visibles
            int visibles = dgvPropietarios.Rows.Cast<DataGridViewRow>().Count(f => f.Visible && !f.IsNewRow);
            lblContador.Text = $"{visibles } resultados encontrados";
        }

        private void CargarDatosEnTabla()
        {
            dgvPropietarios.Rows.Clear();
            if (File.Exists(rutaArchivo))
            {
                var lineasPropietarios = File.ReadAllLines(rutaArchivo).Skip(1);

                // Cargamos mascotas para contar cuántas pertenecen a cada dueño
                List<string> listaMascotas = File.Exists(rutaMascotas)
                    ? File.ReadAllLines(rutaMascotas).Skip(1).ToList()
                    : new List<string>();

                foreach (var linea in lineasPropietarios)
                {
                    var campos = linea.Split(',');
                    if (campos.Length >= 4)
                    {
                        string idProp = campos[0];
                        // En mascotas.csv, el ID del dueño suele ser la columna índice 5
                        int conteoMascotas = listaMascotas.Count(m => m.Split(',').Length > 5 && m.Split(',')[5] == idProp);

                        dgvPropietarios.Rows.Add(campos[0], campos[1], campos[2], campos[3], conteoMascotas);
                    }
                }
            }
            lblContador.Text = $"{dgvPropietarios.Rows.Cast<DataGridViewRow>().Count(f => f.Visible && !f.IsNewRow)} propietarios registrados";
        }

        private void dgvPropietarios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvPropietarios.Rows[e.RowIndex];
                txtID.Text = fila.Cells[0].Value?.ToString();
                txtNombre.Text = fila.Cells[1].Value?.ToString();
                txtTelefono.Text = fila.Cells[2].Value?.ToString();
                txtCorreo.Text = fila.Cells[3].Value?.ToString();

                // Recuperamos la dirección del CSV (ya que no está en el DataGridView)
                if (File.Exists(rutaArchivo))
                {
                    var linea = File.ReadAllLines(rutaArchivo).FirstOrDefault(l => l.StartsWith(txtID.Text + ","));
                    if (linea != null) txtDireccion.Text = linea.Split(',')[4];
                }
            }
        }

        private void CargarIDNuevo()
        {
            int maxId = 0;
            if (File.Exists(rutaArchivo))
            {
                var lineas = File.ReadAllLines(rutaArchivo).Skip(1);
                foreach (var linea in lineas)
                {
                    string idLimpio = linea.Split(',')[0].Replace("P", "");
                    if (int.TryParse(idLimpio, out int idActual))
                    {
                        if (idActual > maxId) maxId = idActual;
                    }
                }
            }
            // Genera P01, P02, etc.
            txtID.Text = "P" + (maxId + 1).ToString("D2");
        }

        private void btnLimpiar_Click(object sender, EventArgs e) => LimpiarInterfaz();

        private void LimpiarInterfaz()
        {
            txtNombre.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
            txtDireccion.Clear();
            txtBuscar.Clear();
            CargarDatosEnTabla();
            CargarIDNuevo();
        }

        private bool ValidarCampos()
        {
            // REGLA DE ORO: Debe empezar con P y tener números
            string id = txtID.Text;
            if (string.IsNullOrWhiteSpace(id) || !id.StartsWith("P") || id.Length < 2)
            {
                MessageBox.Show("El ID debe iniciar con la letra 'P' seguida de números (Ej: P01).", "Error de Formato");
                txtID.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtNombre.Text)) { MessageBox.Show("Falta el nombre."); txtNombre.Focus(); return false; }
            if (string.IsNullOrWhiteSpace(txtTelefono.Text)) { MessageBox.Show("Falta el teléfono."); txtTelefono.Focus(); return false; }

            return true;
        }
    }
}